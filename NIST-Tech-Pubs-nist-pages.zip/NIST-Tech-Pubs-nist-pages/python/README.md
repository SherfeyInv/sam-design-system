https://bibtexparser.readthedocs.io/en/master/tutorial.html#step-3-export
